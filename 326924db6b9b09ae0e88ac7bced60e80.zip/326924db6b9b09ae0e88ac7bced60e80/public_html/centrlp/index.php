<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Privado
 */

get_header(); ?>

<main class="blog-container">
    <header class="blog-header" style="background: url('<?php echo esc_url($codetic_privado['privado_blog_bg_image']['url']); ?>') no-repeat fixed center center / cover;">
        <div class="header-inner">
            <a href=" <?php echo site_url(); ?> " class="btn back-to-home"><i class="fa fa-home fa-fw"></i>Home</a>
                <div class="header-content">
                    <span><i class="fa fa-3x <?php echo esc_attr($codetic_privado['privado_blog_page_icon']);?>"></i></span>
                    <h2><?php echo esc_html($codetic_privado['privado_blog_page_title']);?></h2>
                    <p class="blog-desc"><?php echo esc_html($codetic_privado['privado_blog_page_subtitle']);?></p>
                </div>

            <a href="#blog-list" class="scroll-down"></a>
        </div>
    </header>
	<section id="blog-list">

	<div class="col-md-8 col-md-push-4 blog-list-container">

		<?php if ( have_posts() ) : ?>

			<?php /* Start the Loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>

				<?php
					/* Include the Post-Format-specific template for the content.
					 * If you want to override this in a child theme, then include a file
					 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
					 */
					get_template_part( 'content', get_post_format() );
				?>

			<?php endwhile; ?>

		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; ?>
		
	<?php get_template_part( 'content', 'pagination' ); ?>
	</div><!-- Blog List container end -->
	</section>
	<!-- #Blog List end-->

<?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>
