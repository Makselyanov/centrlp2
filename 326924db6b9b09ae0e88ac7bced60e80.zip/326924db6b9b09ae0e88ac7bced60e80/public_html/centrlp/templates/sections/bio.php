<?php
global $codetic_privado;
if($codetic_privado['privado_bio_section_display']){
?>
<!-- about me -->
<section class="row about-me">
    <div class="col-sm-5 col-sm-offset-1 profile-image">
        <div class="pp-container">
            <img src="<?php echo $codetic_privado['privado_bio_image']['url']; ?>" alt=""/>
        </div>
        <h2>
            <span><?php echo esc_html($codetic_privado['privado_bio_first_name']);?></span>
            <span><?php echo esc_html($codetic_privado['privado_bio_last_name']);?></span>
        </h2>
        <h3><?php echo esc_html($codetic_privado['privado_bio_designation']);?></h3>
    
    </div>
    <!--.Profile image end-->

    <!-- bio-->
    <div class="col-sm-6 bio" style="background: url('<?php echo $codetic_privado['privado_bio_bg_image']['url']; ?>') no-repeat scroll center center / cover;">
        <div class="bio-inner">
            <div class="col-md-10">
              <div class="bio-description">
                <?php echo wpautop($codetic_privado['privado_bio_description']);?>
              </div>

                <div class="buttons">
                    <a href="<?php echo esc_url($codetic_privado ['privado_hire_button_url']);?>" class="btn hire-me"><?php echo $codetic_privado['privado_hire_button'];?></a>
                    <a href="<?php echo esc_url($codetic_privado['privado_download_button_url']);?>" target="_blank" class="btn download-resume"><?php echo $codetic_privado['privado_download_button'];?></a>
                </div>

            </div>
            </div>
    </div>
    <!-- .bio End -->
</section>
<!-- .about-me end-->
<?php } ?>