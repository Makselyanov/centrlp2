<?php
global $codetic_privado;
if($codetic_privado['privado_testimonials_section_display']){
?>

<?php $limit = $codetic_privado['testimonial_number']; $order = get_order_value($codetic_privado['testimonial_post_order']); $testimonials = privado_get_custom_posts('testimonial', $limit, $order); ?>

<!-- Testimonials Section
================================================== -->
<section class="row testimonials">
    <div class="over-div"></div>
    <div class="sec-divider"></div>
    <h2 class="section-title"><?php echo esc_html($codetic_privado['privado_testimonial_title']);?></h2>

<?php if ( $testimonials ) : ?>
    <div class="col-md-8 col-md-offset-2 text-container">
        <div id="testimonial-slides" class="owl-carousel">
        <?php foreach ($testimonials as $testimonial) : $testimonial_meta = get_post_meta($testimonial->ID); ?>
            <div>
                <blockquote>
                    <p><?php echo wp_strip_all_tags($testimonial_meta['_privado_testimonial_description'][0]); ?></p>
                    <cite><?php echo esc_html($testimonial_meta['_privado_testimonial_name'][0]); ?></cite>
                </blockquote>
            </div>
            <!-- Single testimonial -->
        <?php endforeach; ?>
        </div>
        <!-- Owl Carousel End -->
    </div>
<?php endif; ?>
    <!-- text-container ends -->

</section>
<!-- Testimonials Section End-->
<?php } ?>

<?php
if($codetic_privado['privado_portfolio_facts_display']){
    get_template_part("templates/sections/fun-facts");
?>
<?php } ?>
