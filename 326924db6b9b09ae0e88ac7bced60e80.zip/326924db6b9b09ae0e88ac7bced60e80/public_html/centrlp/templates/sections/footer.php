<?php
global $codetic_privado;
?>

<footer id="footer" class="row footer">
    <?php echo wpautop($codetic_privado['privado_footer']);?>
</footer>
<!--footer end-->

</article>
<!-- .page-info -->
</section> <!-- Single Page end -->