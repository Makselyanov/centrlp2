<?php
global $codetic_privado;

$home_url = site_url();
$blog_url = $codetic_privado['privado_blog_url'];
$post_numbers = "ignore_sticky_posts=1&posts_per_page=".$codetic_privado['recent_post_number'];

if($codetic_privado['privado_blog_section_display']){
?>
<!-- Recent post -->
<section class="row recent-post">
    <div class="sec-divider"></div>
    <h2 class="section-title"><?php echo esc_html($codetic_privado['privado_blog_title']);?></h2>

    <div class="row recent-post-list fig-effects">

    <?php $the_query = new WP_Query( $post_numbers ); ?>

    <?php while ($the_query -> have_posts()) : $the_query -> the_post(); ?>

    <?php $featuredimage = wp_get_attachment_url( get_post_thumbnail_id($post->ID, 'thumbnail') ); ?>


    <div class="col-xs-12 col-sm-6 col-md-4 recent-post-item">
        <figure class="effect-ming">
            <div class="featured-image-container" style="background: url('<?php echo $featuredimage; ?>') no-repeat center center / cover;"></div>
            <figcaption>
                <h2><?php the_title(); ?></h2>
                <p><?php the_excerpt(); ?></p>
                <a href="<?php the_permalink() ?>">View more</a>
            </figcaption>           
        </figure>
        <div class="recent-post-meta">
            <time><i class="fa fa-clock-o fa-fw"></i> <?php the_time( get_option( 'date_format' ) ); ?></time>

            <span class="tags"><i class="fa fa-tags fa-fw"></i> 
                <?php $category = get_the_category();  
                 echo $category[0]->cat_name; 
                ?>
            </span>
        </div>
    </div><!--Single Blog-->
    <?php endwhile;?>

    <div class="col-sm-12 more-btn-container">
    <!--Load more button-->  
        <a href="<?php echo esc_url($blog_url);?>" class="btn btn-load-more"><?php echo esc_html($codetic_privado['privado_see_more_button_text']);?></a>
    </div>
</section>
<!-- recent post end-->

<!-- .about-me end-->
<?php } ?>

<?php
if($codetic_privado['privado_profile_facts_display']){
    get_template_part("templates/sections/fun-facts");
?>
<?php } ?>
