<?php
global $codetic_privado;

$map_lat = $codetic_privado['privado_contact_lat'];
$map_lng = $codetic_privado['privado_contact_lng'];
$map_content = str_replace('"', "'", $codetic_privado['privado_marker_description']);
?>
<section class="row social">
    <div class="col-md-6 address">
        <div class="row location">
            <div class="col-md-12 col-lg-10 col-lg-offset-1">
                <ul>
                    <li>
                        <img src="<?php echo esc_url($codetic_privado['privado_location_icon']['url']); ?>" alt="">
                        <h4><?php echo esc_html($codetic_privado['privado_location_title']);?></h4>
                    </li>
                    <li>
                        <img src="<?php echo esc_url($codetic_privado['privado_phone_icon']['url']); ?>" alt="">
                        <h4><?php echo esc_html($codetic_privado['privado_phone_number']);?></h4>
                    </li>
                    <li>
                        <img src="<?php echo esc_url($codetic_privado['privado_mail_icon']['url']); ?>" alt="">
                        <h4><?php echo esc_html($codetic_privado['privado_email_id']);?></h4>
                    </li>
                </ul>
            </div>
        </div>

        <?php $privado_social_profile_links = privado_social_links();
        if ( !empty( $privado_social_profile_links ) ) : ?>
        <nav class="row social-profiles">
            <div class="col-md-12 col-lg-9 col-lg-offset-2">
                <ul><?php echo $privado_social_profile_links; ?></ul>
            </div>
        </nav>
        <?php endif; ?>


    </div>
    <div class="col-md-6 map-container">
        <?php if($codetic_privado['privado_map_display']){?>
            <div id="map" data-lat="<?php echo esc_attr($map_lat);?>" data-lng="<?php echo esc_attr($map_lng);?>" data-con="<?php echo wpautop($map_content);?>"></div>
        <?php } ?>
    </div>


</section>
<!--Social End-->
</section>
<!--Contact End-->