<?php
global $codetic_privado;
?>
<section class="row fun-facts" style="background: url('<?php echo $codetic_privado['privado_fun_facts_bg']['url']; ?>') no-repeat scroll center center / cover;">
    <ul>
        <li>
            <h3><?php echo $codetic_privado['fun_facts_title_1'];?></h3>
            <h5><?php echo esc_html($codetic_privado['fun_facts_subtitle_1']);?></h5>
        </li>
        <li>
            <h3><?php echo $codetic_privado['fun_facts_title_2'];?></h3>
            <h5><?php echo esc_html($codetic_privado['fun_facts_subtitle_2']);?></h5>
        </li>
        <li>
            <h3><?php echo $codetic_privado['fun_facts_title_3'];?></h3>
            <h5><?php echo esc_html($codetic_privado['fun_facts_subtitle_3']);?></h5>
        </li>
        <li>
            <h3><?php echo $codetic_privado['fun_facts_title_4'];?></h3>
            <h5><?php echo esc_html($codetic_privado['fun_facts_subtitle_4']);?></h5>
        </li>
        <li>
            <h3><?php echo $codetic_privado['fun_facts_title_5'];?></h3>
            <h5><?php echo esc_html($codetic_privado['fun_facts_subtitle_5']);?></h5>
        </li>
    </ul>
</section>
<!-- Fun facts end-->