<?php
global $codetic_privado;
if($codetic_privado['privado_services_section_display']){
?>


<?php $limit = $codetic_privado['service_post_number']; $order = get_order_value($codetic_privado['service_post_order']); $services = privado_get_custom_posts('service', $limit, $order); ?>

<!-- services-->
<section class="row services">
    <div class="over-div"></div>
    <div class="sec-divider"></div>
    <h2 class="section-title"><?php echo esc_html($codetic_privado['privado_services_title']);?></h2>

<?php if ( $services ) : ?>
    <div class="container service-list">
        <div class="row">
                
                <?php foreach ($services as $service) : $service_meta = get_post_meta($service->ID); ?>
                    <div class="col-sm-6 col-md-3 service">
                        <span><i class="fa fa-3x <?php echo $service_meta['_privado_service_icon'][0]; ?>"></i></span>
                        <h3><?php echo $service_meta['_privado_service_title'][0]; ?></h3>
                        <p><?php echo wpautop($service_meta['_privado_service_description'][0]);?></p>
                    </div> <!--single service -->
          
                <?php endforeach; ?>

        </div> <!-- row of services -->
    </div> <!-- service list-->
<?php endif; ?>

</section>
<!-- #Services end-->

<?php } ?>