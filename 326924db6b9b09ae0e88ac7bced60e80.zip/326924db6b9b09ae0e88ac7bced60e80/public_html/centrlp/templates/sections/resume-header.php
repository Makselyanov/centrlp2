<?php
global $codetic_privado;
?>
<!-- Resume Page -->
<section class="single-page is-loaded">

<!-- Resume Page Title-->
    <header class="page-title">
        <span><i class="fa fa-3x <?php echo esc_attr($codetic_privado['privado_resume_page_icon']);?>"></i></span>
        <h2><?php echo esc_html($codetic_privado['privado_resume_page_title']);?></h2>
        <p class="menu-desc"><?php echo esc_html($codetic_privado['privado_resume_page_subtitle']);?></p>
    </header>
    <!-- .page-title -->

<!-- Resume Page Contents-->
    <article class="page-info container-fluid">