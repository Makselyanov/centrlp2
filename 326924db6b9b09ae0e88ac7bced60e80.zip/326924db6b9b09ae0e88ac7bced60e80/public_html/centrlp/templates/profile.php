<?php

get_template_part("templates/sections/profile-header");
get_template_part("templates/sections/bio");
get_template_part("templates/sections/services");
get_template_part("templates/sections/recent-post");
get_template_part("templates/sections/footer");
