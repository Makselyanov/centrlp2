<?php
global $codetic_privado;
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <main class="page-container">
 *
 * @package Privado
 */
?>

<!doctype html>
<html <?php language_attributes(); ?> class="no-js">

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no;">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
    <title><?php wp_title( '|', true, 'right' ); ?></title>

    <!-- Favicon-->
	<link rel="shortcut icon" href="<?php echo esc_url($codetic_privado['privado_favicon']['url']); ?>" >

 <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

  <!-- Preloader --> 
    <div id="preloader">
      <div class="loader"></div>    
    </div><!--preloader end-->

    <nav class="primary-menu">

    <div class="nav-header">
        <h2><?php echo esc_html($codetic_privado['privado_blog_page_title']);?></h2>
    </div>
        <?php
            $args = array(
                'container'         => 'div',
                'menu_class'      => 'main-menu',
                'theme_location'    => 'primary',
            );
            wp_nav_menu( $args ); ?>
    </nav>

<div class="menu-expander">      
      <a id="nav-expander" class="nav-expander fixed"><span></span></a>
</div>