<?php
/**
 * Template Name: Privado HomePage
 */

get_header("privado");
get_template_part("templates/profile");
get_template_part("templates/resume");
get_template_part("templates/portfolio");
get_template_part("templates/contact");
get_footer("privado");
