<?php
global $codetic_privado;
/**
 * The template for displaying 404 pages (not found).
 *
 * @package Privado
 */

$home_url = site_url();
$blog_url = esc_html($codetic_privado['privado_blog_url']);
get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<div class="error-container">
				<section class="error-404 not-found text-center">
					<header class="error-header">
						<div class="error-image">
							<img src="<?php echo esc_url($codetic_privado['privado_error_image']['url']); ?>" alt="404">
						</div>
						<h1 class="error-title"><?php echo esc_html($codetic_privado['privado_error_page_title']);?></h1>
					</header><!-- .page-header -->

					<div class="page-content">
						<p><?php echo wpautop($codetic_privado['privado_error_page_description']);?></p>

						<?php get_search_form(); ?>

						<div class="back-button-container">
						<?php if($codetic_privado['privado_error_home_display']){?>
							<a href="<?php echo $home_url;?>" class="btn back-to-home"><i class="fa fa-home fa-fw"></i>Back to Home</a>
							<?php } ?>

						<?php if($codetic_privado['privado_error_blog_display']){?>
							<a href="<?php echo $blog_url;?>" class="btn back-to-home"><i class="fa fa-pencil fa-fw"></i>Go to Blog</a>
							<?php } ?>
						</div>
					</div>

				</section><!-- .error-404 -->
			</div>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer(); ?>
