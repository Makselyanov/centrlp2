<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Privado
 */
?>


    <a href="#" class="page-close">Close</a>
    <a href="#" class="page-scroll">Scroll</a>
</main>
<!-- .page-container -->

<?php wp_footer(); ?>

</body>

</html>