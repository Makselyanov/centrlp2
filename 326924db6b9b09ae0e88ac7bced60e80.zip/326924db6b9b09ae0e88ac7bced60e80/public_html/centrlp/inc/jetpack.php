<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Privado
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function privado_jetpack_setup() {
	add_theme_support( 'infinite-scroll', array(
		'container' => 'content',
		'footer'    => 'footer',
	) );
}
add_action( 'after_setup_theme', 'privado_jetpack_setup' );
