<?php

add_filter( 'cmb2_meta_boxes', 'privado_testimonial_metaboxes' );

function privado_testimonial_metaboxes(array $meta_boxes){
    $prefix = '_privado_';

    $meta_boxes['testimonial_metabox'] = array(
        'id'            => 'testimonial_metabox',
        'title'         => __( 'Testimonial Options', 'privado' ),
        'object_types'  => array( 'testimonial', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        'fields'        => array(
            array(
                'name' => __('Person Name ',"privado"),
                'id' => $prefix . 'testimonial_name',
                'type' => 'text_medium'
            ),
            array(
                'name' => __('Testimonial ',"privado"),
                'id' => $prefix . 'testimonial_description',
                'type' => 'textarea'
            ),
        ),
    );

    return $meta_boxes;
}
