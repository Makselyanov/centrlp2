<?php

$sections[] = array(
    'title' => __('Profile Settings', 'privado'),
    'icon' => ' el-icon-glasses',
    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
    'fields' => array(

        array(
            'id' => 'privado_bio_section_display',
            'type' => 'switch',
            'title' => __('Display Bio', 'privado'),
            'default' => '1',
        ),

        array(
            'id' => 'privado_services_section_display',
            'type' => 'switch',
            'title' => __('Display Services', 'privado'),
            'default' => '1',
        ),

        array(
            'id' => 'privado_blog_section_display',
            'type' => 'switch',
            'title' => __('Display Recent Post', 'privado'),
            'default' => '1',
        ),

        array(
            'id' => 'privado_profile_facts_display',
            'type' => 'switch',
            'title' => __('Display Fun Facts', 'privado'),
            'default' => '1',
        ),

        array(
            'id' => 'privado_profile_page_title',
            'type' => 'text',
            'title' => __('Profile Page Title', 'privado'),
            'default' => 'Profile',
        ),

        array(
            'id' => 'privado_profile_page_icon',
            'type' => 'text',
            'title' => __('Profile Page Icon', 'privado'),
            'default' => "fa-user",
            'description' => "Font Awesome icon class for Profile",
        ),
        array(
            'id' => 'privado_profile_page_subtitle',
            'type' => 'text',
            'title' => __('Profile Page Subtitle', 'privado'),
            'default' => 'A Brief About Me...',
        ),
        array(
            'id'       => 'privado_profile_section_image',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Profile Page Background Image', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/img-1-large.jpg"
            ),

        ),

        array(
            'id'       => 'privado_profile_section_overlay',
            'type'     => 'color',
            'title'    => __('Profile Section overlay Color', 'privado'),
            'default'  => '#191D21',
            'validate' => 'color',
            'transparent' => false,
        ),

        array(
            'id'       => 'privado_bio_image',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Bio Avatar Image', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/avatar.png"
            ),

        ),

        array(
            'id'       => 'privado_bio_bg_image',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Bio Description Background', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/bg-4.jpg"
            ),

        ),

        array(
            'id' => 'privado_bio_first_name',
            'type' => 'text',
            'title' => __('Bio First Name', 'privado'),
            'default' => 'Nazmul H.',
        ),

        array(
            'id' => 'privado_bio_last_name',
            'type' => 'text',
            'title' => __('Bio Last Name', 'privado'),
            'default' => 'Rupok',
        ),

        array(
            'id' => 'privado_bio_designation',
            'type' => 'text',
            'title' => __('Bio Designation', 'privado'),
            'default' => 'Full Stack Web &amp; Mobile Application Developer',
        ),

         array(
            'id' => 'privado_bio_description',
            'type' => 'editor',
            'title' => __('Bio Description', 'privado'),
            'default' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.

                Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. ',
        ),

        array(
            'id' => 'privado_hire_button',
            'type' => 'text',
            'title' => __('Hire Me Button Text', 'privado'),
            'default' => 'Hire Me',
        ),

        array(
            'id' => 'privado_hire_button_url',
            'type' => 'text',
            'title' => __('Hire Me Button URL', 'privado'),
            'default' => 'mailto:mail@yourdomain.com',
        ),

        array(
            'id' => 'privado_download_button',
            'type' => 'text',
            'title' => __('Download Resume Button Text', 'privado'),
            'default' => 'Download Resume',
        ),

        array(
            'id' => 'privado_download_button_url',
            'type' => 'text',
            'title' => __('Download Resume Button URL', 'privado'),
            'default' => 'http://yourwebsite.com/resume.pdf',
        ),


        // Service Section
        array(
           'id' => 'section-service',
           'type' => 'section',
           'title' => __('Service Section Settings', 'privado'),
           'indent' => true,
           'required' => array('privado_services_section_display', '=', '1')
        ),

        array(
            'id' => 'privado_services_title',
            'type' => 'text',
            'title' => __('Services Title', 'privado'),
            'default' => 'Project you can offer',
            'required' => array('privado_services_section_display', '=', '1')
        ),

        array(
            'id'       => 'privado_services_icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Services Icon', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/icons/services-icon.svg"
            ),
            'required' => array('privado_services_section_display', '=', '1')
        ),

        array(
            'id'        => 'service_post_number',
            'type'      => 'slider',
            'title'     => __('Max Service Appear', 'privado'),
            'desc'      => __('Min: 4, max: 16, step: 4, default value: 4', 'privado'),
            "default"   => 4,
            "min"       => 4,
            "step"      => 4,
            "max"       => 16,
            'display_value' => 'Max Post',
            'required' => array('privado_services_section_display', '=', '1')
        ),

        array(
            'id'       => 'service_post_order',
            'type'     => 'select',
            'title'    => __('Display Order Type', 'privado'), 
            'desc'     => __('Display Services in Ascending or Descending Order', 'privado'),
            'options'  => array(
                '1' => 'Ascending Order',
                '2' => 'Descending Order',
            ),
            'default'  => '2',
            'required' => array('privado_services_section_display', '=', '1')
        ),

        // Recent Post Section
        array(
           'id' => 'section-recent-post',
           'type' => 'section',
           'title' => __('Recent Post Section Settings', 'privado'),
           'indent' => true 
        ),
        array(
            'id' => 'privado_blog_title',
            'type' => 'text',
            'title' => __('Recent Post Title', 'privado'),
            'default' => 'From the Blog',
        ),

        array(
            'id'       => 'privado_blog_icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Blog Icon', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/icons/blog-icon.svg"
            ),
        ),

        array(
            'id'        => 'recent_post_number',
            'type'      => 'slider',
            'title'     => __('Max Post Appear', 'privado'),
            'desc'      => __('Min: 3, max: 30, step: 3, default value: 3', 'privado'),
            "default"   => 3,
            "min"       => 3,
            "step"      => 3,
            "max"       => 16,
            'display_value' => 'Max Post',
        ),

        array(
            'id' => 'privado_blog_url',
            'type' => 'text',
            'title' => __('Blog Page URL (For See More Link)', 'privado'),
            'default' => '/blog',
        ),

        array(
            'id' => 'privado_see_more_button_text',
            'type' => 'text',
            'title' => __('See more button text', 'privado'),
            'default' => 'See More',
        ),

    )
);
