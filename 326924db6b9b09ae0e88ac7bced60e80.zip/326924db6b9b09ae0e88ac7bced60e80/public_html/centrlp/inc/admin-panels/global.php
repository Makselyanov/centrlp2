<?php

$sections[] = array(
    'title' => __('Global Settings', 'privado'),
    'icon' => 'el-icon-home',
    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
    'fields' => array(

        array(
            'id'       => 'privado_body_bg',
            'type'     => 'color',
            'title'    => __('Body Background Color', 'privado'),
            'default'  => '#101524',
            'validate' => 'color',
            'transparent' => false,
        ),

        array(
            'id'       => 'privado_favicon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Favicon Image', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/favicon.png"
            ),
        ),

        array(
            'id'       => 'privado_preloader_image',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Preloader Image', 'privado'),
            'description' => 'Upload your preloader image. You can create your own gif preloader from here - http://preloaders.net/',
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/svg-loaders/puff.svg"
            ),
        ),

        array(
            'id'       => 'privado_preloader_bg',
            'type'     => 'color',
            'title'    => __('Preloader Background Color', 'privado'),
            'default'  => '#101524',
            'validate' => 'color',
            'transparent' => false,
        ),


        array(
            'id' => 'privado_custom_css',
            'type' => 'ace_editor',
            'title' => __('Custom CSS', 'intima'),
            'description' => 'Write your custom CSS code here. No &lt;style&gt; tag required.'
        ),

    )
);
