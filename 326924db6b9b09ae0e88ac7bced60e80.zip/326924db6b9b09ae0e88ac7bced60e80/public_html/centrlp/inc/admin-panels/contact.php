<?php

$sections[] = array(
    'title' => __('Contact Settings', 'privado'),
    'icon' => 'el-icon-envelope',
    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
    'fields' => array(

        array(
            'id' => 'privado_contact_page_title',
            'type' => 'text',
            'title' => __('Contact Page Title', 'privado'),
            'default' => 'Contact',
        ),

        array(
            'id' => 'privado_contact_page_icon',
            'type' => 'text',
            'title' => __('Contact Icon', 'privado'),
            'default' => "fa-paper-plane",
            'description' => "Font Awesome icon class for Contact",
        ),
        array(
            'id' => 'privado_contact_page_subtitle',
            'type' => 'text',
            'title' => __('Contact Page Subtitle', 'privado'),
            'default' => 'Way to Reach Me...',
        ),

        array(
            'id'       => 'privado_contact_section_image',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Contact Page Background Image', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/img-4-large.jpg"
            ),

        ),

        array(
            'id'       => 'privado_contact_section_overlay',
            'type'     => 'color',
            'title'    => __('Contact Section overlay Color', 'privado'),
            'default'  => '#273a3f',
            'validate' => 'color',
            'transparent' => false,
        ),

        // section contact form
        array(
           'id' => 'section_contact_form_start',
           'type' => 'section',
           'title' => __('Contact Form Settings', 'privado'),
           'indent' => true 
        ),
        array(
            'id' => 'privado_contact_form_title',
            'type' => 'text',
            'title' => __('Contact Form Title', 'privado'),
            'default' => 'Drop me a line',
        ),

        array(
            'id'       => 'privado_contact_form_icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Contact Form Icon', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/icons/mail-icon.svg"
            ),
        ),

        array(
            'id' => 'privado_contact_form_shortcode',
            'type' => 'text',
            'title' => __('Contact Form 7 shorcode', 'privado'),
            'default' => '[contact-form-7 id="100" title="Contact Form 1"]',
        ),

        // section social and address
        array(
           'id' => 'section_social_address_start',
           'type' => 'section',
           'title' => __('Address Settings', 'privado'),
           'indent' => true 
        ),
        array(
            'id'       => 'privado_location_icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Location Icon', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/icons/location-map.svg"
            ),

        ),
        array(
            'id' => 'privado_location_title',
            'type' => 'text',
            'title' => __('Location Text', 'privado'),
            'default' => 'Dhaka, Bangladesh',
        ),
        

        array(
            'id'       => 'privado_phone_icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Phone Icon', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/icons/phone-icon.svg"
            ),

        ),
        array(
            'id' => 'privado_phone_number',
            'type' => 'text',
            'title' => __('Phone Number', 'privado'),
            'default' => '+880 123 456 789',
        ),        

        array(
            'id'       => 'privado_mail_icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Email Icon', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/icons/email-icon.svg"
            ),

        ),
        array(
            'id' => 'privado_email_id',
            'type' => 'text',
            'title' => __('Email ID', 'privado'),
            'default' => 'mail@rupok.me',
        ),

        // section map
        array(
           'id' => 'section_map_start',
           'type' => 'section',
           'title' => __('Google Map Settings', 'privado'),
           'indent' => true 
        ),
        array(
            'id' => 'privado_map_display',
            'type' => 'switch',
            'title' => __('Display Map', 'privado'),
            'default' => '1',
        ),
       array(
            'id' => 'privado_contact_lat',
            'type' => 'text',
            'title' => __('Map Latitude', 'privado'),
            'default' => "23.807107",
            'required' => array('privado_map_display', '=', '1')
        ),
        array(
            'id' => 'privado_contact_lng',
            'type' => 'text',
            'title' => __('Map Longitude', 'privado'),
            'default' => "90.368597",
            'required' => array('privado_map_display', '=', '1')
        ),
        array(
            'id' => 'privado_marker_description',
            'type' => 'editor',
            'title' => __('Marker Details', 'privado'),
            'default' => "<p> Mirpur, Dhaka, Bangladesh </p>",
            'required' => array('privado_map_display', '=', '1')
        ),
    )
);
