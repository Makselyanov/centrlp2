<?php

$sections[] = array(
    'title' => __('Resume Settings', 'privado'),
    'icon' => 'el-icon-user',
    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
    'fields' => array(

        array(
            'id' => 'privado_resume_section_display',
            'type' => 'switch',
            'title' => __('Display Resume', 'privado'),
            'default' => '1',
        ),

        array(
            'id' => 'privado_skills_section_display',
            'type' => 'switch',
            'title' => __('Display Skills', 'privado'),
            'default' => '1',
        ),

        array(
            'id' => 'privado_recognition_section_display',
            'type' => 'switch',
            'title' => __('Display Recognition', 'privado'),
            'default' => '1',
        ),

        array(
            'id' => 'privado_resume_page_title',
            'type' => 'text',
            'title' => __('Resume Page Title', 'privado'),
            'default' => 'Resume',
        ),

        array(
            'id' => 'privado_resume_page_icon',
            'type' => 'text',
            'title' => __('Resume Page Icon', 'privado'),
            'default' => "fa-file-text",
            'description' => "Font Awesome icon class for Resume",
        ),
        array(
            'id' => 'privado_resume_page_subtitle',
            'type' => 'text',
            'title' => __('Resume Page Subtitle', 'privado'),
            'default' => 'My Academic Qualifications...',
        ),

        array(
            'id'       => 'privado_resume_section_image',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Resume Page Background Image', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/img-2-large.jpg"
            ),

        ),

        array(
            'id'       => 'privado_resume_section_overlay',
            'type'     => 'color',
            'title'    => __('Resume Section overlay Color', 'privado'),
            'default'  => '#1F2628',
            'validate' => 'color',
            'transparent' => false,
        ),


        // Education Section
        array(
           'id' => 'section-education',
           'type' => 'section',
           'title' => __('Education Section Settings', 'privado'),
           'indent' => true 
        ),

        array(
            'id' => 'privado_education_title',
            'type' => 'text',
            'title' => __('Education Title', 'privado'),
            'default' => '- Education -',
        ),

        array(
            'id'        => 'education_post_number',
            'type'      => 'slider',
            'title'     => __('Max Education Appear', 'privado'),
            'desc'      => __('Min: 1, max: 20, step: 1, default value: 3', 'privado'),
            "default"   => 3,
            "min"       => 1,
            "step"      => 1,
            "max"       => 20,
            'display_value' => 'Max Post',
        ),

        array(
            'id'       => 'education_post_order',
            'type'     => 'select',
            'title'    => __('Display Order Type', 'privado'), 
            'desc'     => __('Display Education in Ascending or Descending Order', 'privado'),
            'options'  => array(
                '1' => 'Ascending Order',
                '2' => 'Descending Order',
            ),
            'default'  => '2',
        ),

        // Employment Section
        array(
           'id' => 'section-employment',
           'type' => 'section',
           'title' => __('Employment Section Settings', 'privado'),
           'indent' => true 
        ),

        array(
            'id' => 'privado_employment_title',
            'type' => 'text',
            'title' => __('Employment Title', 'privado'),
            'default' => '- Employment -',
        ),
        array(
            'id'        => 'employment_post_number',
            'type'      => 'slider',
            'title'     => __('Max Employment Appear', 'privado'),
            'desc'      => __('Min: 1, max: 20, step: 1, default value: 3', 'privado'),
            "default"   => 3,
            "min"       => 1,
            "step"      => 1,
            "max"       => 20,
            'display_value' => 'Max Post',
        ),
        array(
            'id'       => 'employment_post_order',
            'type'     => 'select',
            'title'    => __('Display Order Type', 'privado'), 
            'desc'     => __('Display Employments in Ascending or Descending Order', 'privado'),
            'options'  => array(
                '1' => 'Ascending Order',
                '2' => 'Descending Order',
            ),
            'default'  => '2',
        ),

        // Skills Section
        array(
           'id' => 'section-skills',
           'type' => 'section',
           'title' => __('Skills Section Settings', 'privado'),
           'indent' => true 
        ),

        array(
            'id' => 'privado_skills_title',
            'type' => 'text',
            'title' => __('Skills Title', 'privado'),
            'default' => 'My Key Skills',
        ),

        array(
            'id'       => 'privado_skills_icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Skills Icon', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/icons/ninja.svg"
            ),
        ),

        array(
            'id'=>'privado_skills',
            'type' => 'multi_text',
            'title' => __('Skills', 'privado'),
            'subtitle' => 'Add as many skills as you want. Separate skill name and value (percentage) by comma, ex: JQuery, 90',
            'validate' => '',
            'default' => array(
                'HTML5, 95',
                'CSS3, 90',
                'Sass, 85',
                'jQuery, 70',
                'BackboneJS, 55',
                'AngularJs, 60',
                'PHP, 50',
                'Git, 80',
            ),
            'required' => array('privado_skills_section_display', '=', '1')
        ),

        // Recognition Section
        array(
           'id' => 'section-recognition',
           'type' => 'section',
           'title' => __('Recognition Section Settings', 'privado'),
           'indent' => true 
        ),

        array(
            'id'       => 'privado_recognition_section_image',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Recognition Background Image', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/bg-2.jpg"
            ),

        ),

        array(
            'id' => 'privado_recognition_title',
            'type' => 'text',
            'title' => __('Recognition Title', 'privado'),
            'default' => 'Recognition',
        ),

         array(
            'id' => 'privado_recognition_description',
            'type' => 'editor',
            'title' => __('Recognition Description', 'privado'),
            'default' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum. ',
        ),

        array(
            'id'        => 'recognition_post_number',
            'type'      => 'slider',
            'title'     => __('Max Recognition Appear', 'privado'),
            'desc'      => __('Min: 1, max: 20, step: 1, default value: 4', 'privado'),
            "default"   => 4,
            "min"       => 1,
            "step"      => 1,
            "max"       => 20,
            'display_value' => 'Max Post',
        ),
        array(
            'id'       => 'recognition_post_order',
            'type'     => 'select',
            'title'    => __('Display Order Type', 'privado'), 
            'desc'     => __('Display Recognition in Ascending or Descending Order', 'privado'),
            'options'  => array(
                '1' => 'Ascending Order',
                '2' => 'Descending Order',
            ),
            'default'  => '2',
        ),
    )
);
