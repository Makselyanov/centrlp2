<?php

$sections[] = array(
    'title' => __('404 Page Settings', 'privado'),
    'icon' => ' el-icon-warning-sign',
    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
    'fields' => array(

        array(
            'id'       => 'privado_error_image',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('404 Page Image', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/anonymous.png"
            ),

        ),
        array(
            'id' => 'privado_error_page_title',
            'type' => 'text',
            'title' => __('404 Page Title', 'privado'),
            'default' => 'Oops! That page can&rsquo;t be found.',
        ),

        array(
            'id' => 'privado_error_page_description',
            'type' => 'editor',
            'title' => __('404 Page Description', 'privado'),
            'default' => "It looks like nothing was found at this location. Maybe try one of the links below or a search?",
        ),

        array(
            'id' => 'privado_error_home_display',
            'type' => 'switch',
            'title' => __('Display Back to Home Button', 'privado'),
            'default' => '1',
        ),

        array(
            'id' => 'privado_error_blog_display',
            'type' => 'switch',
            'title' => __('Display Back to Blog Button', 'privado'),
            'default' => '1',
        ),

    )
);
