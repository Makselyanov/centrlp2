<?php

$sections[] = array(
    'title' => __('Fun Facts Options', 'privado'),
    'icon' => 'el-icon-smiley',
    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
    'fields' => array(
        array(
            'id'       => 'privado_fun_facts_bg',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Fun Facts Background', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/fun-bg.jpg"
            ),

        ),
        array(
            'id' => 'fun_facts_title_1',
            'type' => 'text',
            'title' => __('Fun Facts Title 1 (Text or Icon)', 'privado'),
            'default' => '50+',
            'description' => 'Text or Font Awesome Icon (i.e. <code>< i class="fa fa-bicycle"></i></code>, remove space before i)',
        ),
        array(
            'id' => 'fun_facts_subtitle_1',
            'type' => 'text',
            'title' => __('Fun Facts Subtitle 1', 'privado'),
            'default' => 'Clients',
        ),
        array(
            'id' => 'fun_facts_title_2',
            'type' => 'text',
            'title' => __('Fun Facts Title 2', 'privado'),
            'default' => '<i class="fa fa-bicycle"></i>',
        ),
        array(
            'id' => 'fun_facts_subtitle_2',
            'type' => 'text',
            'title' => __('Fun Facts Subtitle 2', 'privado'),
            'default' => 'Cyclist',
        ),
        array(
            'id' => 'fun_facts_title_3',
            'type' => 'text',
            'title' => __('Fun Facts Title 3', 'privado'),
            'default' => '100+',
        ),
        array(
            'id' => 'fun_facts_subtitle_3',
            'type' => 'text',
            'title' => __('Fun Facts Subtitle 3', 'privado'),
            'default' => 'Projects Done',
        ),
        array(
            'id' => 'fun_facts_title_4',
            'type' => 'text',
            'title' => __('Fun Facts Title 4', 'privado'),
            'default' => '<i class="fa fa-camera-retro"></i>',
        ),
        array(
            'id' => 'fun_facts_subtitle_4',
            'type' => 'text',
            'title' => __('Fun Facts Subtitle 4', 'privado'),
            'default' => 'Photographer',
        ),
        array(
            'id' => 'fun_facts_title_5',
            'type' => 'text',
            'title' => __('Fun Facts Title 5', 'privado'),
            'default' => '200+',
        ),
        array(
            'id' => 'fun_facts_subtitle_5',
            'type' => 'text',
            'title' => __('Fun Facts Subtitle 5', 'privado'),
            'default' => 'Coffee Cups',
        ),

    )
);
