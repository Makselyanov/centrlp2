<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru" class="  ">

<head>
    <title>О веб-студии CentrLP - что мы можем Вам предложить</title>
    <meta name="viewport" content="initial-scale=1.0, width=device-width" />
    <meta name="HandheldFriendly" content="true" />
    <meta name="yes" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="CentrLP —  студия разработки и вредрения веб-решений на 1С-Битрикс с последующим их продвижением и сопровождением." />
    <style type="text/css">
        .bx-composite-btn {
            background: url(/bitrix/images/main/composite/sprite-1x.png) no-repeat right 0 #e94524;
            border-radius: 15px;
            color: #fff !important;
            display: inline-block;
            line-height: 30px;
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif !important;
            font-size: 12px !important;
            font-weight: bold !important;
            height: 31px !important;
            padding: 0 42px 0 17px !important;
            vertical-align: middle !important;
            text-decoration: none !important;
        }
        
        @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 2) and (min-resolution: 192dpi) {
            .bx-composite-btn {
                background-image: url(/bitrix/images/main/composite/sprite-2x.png);
                background-size: 42px 124px;
            }
        }
        
        .bx-composite-btn-fixed {
            position: absolute;
            top: -45px;
            right: 15px;
            z-index: 10;
        }
        
        .bx-btn-white {
            background-position: right 0;
            color: #fff !important;
        }
        
        .bx-btn-black {
            background-position: right -31px;
            color: #000 !important;
        }
        
        .bx-btn-red {
            background-position: right -62px;
            color: #555 !important;
        }
        
        .bx-btn-grey {
            background-position: right -93px;
            color: #657b89 !important;
        }
        
        .bx-btn-border {
            border: 1px solid #d4d4d4;
            height: 29px !important;
            line-height: 29px !important;
        }
        
        .bx-composite-loading {
            display: block;
            width: 40px;
            height: 40px;
            background: url(/bitrix/images/main/composite/loading.gif);
        }
    </style>
    <script type="text/javascript" data-skip-moving="true">
        (function(w, d) {
            var v = w.frameCacheVars = {
                'CACHE_MODE': 'HTMLCACHE',
                'banner': {
                    'url': 'http://www.1c-bitrix.ru/composite/',
                    'text': 'Быстро с 1С-Битрикс',
                    'bgcolor': '#E94524',
                    'style': 'white'
                },
                'storageBlocks': [],
                'dynamicBlocks': {
                    'options-block': 'd41d8cd98f00',
                    'cabinet-link1': 'd41d8cd98f00',
                    'cabinet-link2': 'd41d8cd98f00',
                    'basket-link1': 'd41d8cd98f00',
                    'basket-link2': 'd41d8cd98f00',
                    'cabinet-link3': 'd41d8cd98f00'
                },
                'AUTO_UPDATE': true,
                'AUTO_UPDATE_TTL': '0'
            };
            var inv = false;
            if (v.AUTO_UPDATE === false) {
                if (v.AUTO_UPDATE_TTL && v.AUTO_UPDATE_TTL > 0) {
                    var lm = Date.parse(d.lastModified);
                    if (!isNaN(lm)) {
                        var td = new Date().getTime();
                        if ((lm + v.AUTO_UPDATE_TTL * 1000) >= td) {
                            w.frameRequestStart = false;
                            w.preventAutoUpdate = true;
                            return;
                        }
                        inv = true;
                    }
                } else {
                    w.frameRequestStart = false;
                    w.preventAutoUpdate = true;
                    return;
                }
            }
            var r = w.XMLHttpRequest ? new XMLHttpRequest() : (w.ActiveXObject ? new w.ActiveXObject("Microsoft.XMLHTTP") : null);
            if (!r) {
                return;
            }
            w.frameRequestStart = true;
            var m = v.CACHE_MODE;
            var l = w.location;
            var x = new Date().getTime();
            var q = "?bxrand=" + x + (l.search.length > 0 ? "&" + l.search.substring(1) : "");
            var u = l.protocol + "//" + l.host + l.pathname + q;
            r.open("GET", u, true);
            r.setRequestHeader("BX-ACTION-TYPE", "get_dynamic");
            r.setRequestHeader("BX-CACHE-MODE", m);
            r.setRequestHeader("BX-CACHE-BLOCKS", v.dynamicBlocks ? JSON.stringify(v.dynamicBlocks) : "");
            if (inv) {
                r.setRequestHeader("BX-INVALIDATE-CACHE", "Y");
            }
            try {
                r.setRequestHeader("BX-REF", d.referrer || "");
            } catch (e) {}
            if (m === "APPCACHE") {
                r.setRequestHeader("BX-APPCACHE-PARAMS", JSON.stringify(v.PARAMS));
                r.setRequestHeader("BX-APPCACHE-URL", v.PAGE_URL ? v.PAGE_URL : "");
            }
            r.onreadystatechange = function() {
                if (r.readyState != 4) {
                    return;
                }
                var a = r.getResponseHeader("BX-RAND");
                var b = w.BX && w.BX.frameCache ? w.BX.frameCache : false;
                if (a != x || !((r.status >= 200 && r.status < 300) || r.status === 304 || r.status === 1223 || r.status === 0)) {
                    var f = {
                        error: true,
                        reason: a != x ? "bad_rand" : "bad_status",
                        url: u,
                        xhr: r,
                        status: r.status
                    };
                    if (w.BX && w.BX.ready) {
                        BX.ready(function() {
                            setTimeout(function() {
                                BX.onCustomEvent("onFrameDataRequestFail", [f]);
                            }, 0);
                        });
                    } else {
                        w.frameRequestFail = f;
                    }
                    return;
                }
                if (b) {
                    b.onFrameDataReceived(r.responseText);
                    if (!w.frameUpdateInvoked) {
                        b.update(false);
                    }
                    w.frameUpdateInvoked = true;
                } else {
                    w.frameDataString = r.responseText;
                }
            };
            r.send();
        })(window, document);
    </script>
    <script type="text/javascript" data-skip-moving="true">
        (function(w, d, n) {
            var cl = "bx-core";
            var ht = d.documentElement;
            var htc = ht ? ht.className : undefined;
            if (htc === undefined || htc.indexOf(cl) !== -1) {
                return;
            }
            var ua = n.userAgent;
            if (/(iPad;)|(iPhone;)/i.test(ua)) {
                cl += " bx-ios";
            } else if (/Android/i.test(ua)) {
                cl += " bx-android";
            }
            cl += (/(ipad|iphone|android|mobile|touch)/i.test(ua) ? " bx-touch" : " bx-no-touch");
            cl += w.devicePixelRatio && w.devicePixelRatio >= 2 ? " bx-retina" : " bx-no-retina";
            var ieVersion = -1;
            if (/AppleWebKit/.test(ua)) {
                cl += " bx-chrome";
            } else if ((ieVersion = getIeVersion()) > 0) {
                cl += " bx-ie bx-ie" + ieVersion;
                if (ieVersion > 7 && ieVersion < 10 && !isDoctype()) {
                    cl += " bx-quirks";
                }
            } else if (/Opera/.test(ua)) {
                cl += " bx-opera";
            } else if (/Gecko/.test(ua)) {
                cl += " bx-firefox";
            }
            if (/Macintosh/i.test(ua)) {
                cl += " bx-mac";
            }
            ht.className = htc ? htc + " " + cl : cl;

            function isDoctype() {
                if (d.compatMode) {
                    return d.compatMode == "CSS1Compat";
                }
                return d.documentElement && d.documentElement.clientHeight;
            }

            function getIeVersion() {
                if (/Opera/i.test(ua) || /Webkit/i.test(ua) || /Firefox/i.test(ua) || /Chrome/i.test(ua)) {
                    return -1;
                }
                var rv = -1;
                if (!!(w.MSStream) && !(w.ActiveXObject) && ("ActiveXObject" in w)) {
                    rv = 11;
                } else if (!!d.documentMode && d.documentMode >= 10) {
                    rv = 10;
                } else if (!!d.documentMode && d.documentMode >= 9) {
                    rv = 9;
                } else if (d.attachEvent && !/Opera/.test(ua)) {
                    rv = 8;
                }
                if (rv == -1 || rv == 8) {
                    var re;
                    if (n.appName == "Microsoft Internet Explorer") {
                        re = new RegExp("MSIE ([0-9]+[\.0-9]*)");
                        if (re.exec(ua) != null) {
                            rv = parseFloat(RegExp.$1);
                        }
                    } else if (n.appName == "Netscape") {
                        rv = 11;
                        re = new RegExp("Trident/.*rv:([0-9]+[\.0-9]*)");
                        if (re.exec(ua) != null) {
                            rv = parseFloat(RegExp.$1);
                        }
                    }
                }
                return rv;
            }
        })(window, document, navigator);
    </script>

    <link href="/bitrix/cache/css/s1/aspro-digital/kernel_main/kernel_main_v1.css?155301399828845" type="text/css" rel="stylesheet" />
    <link href="/bitrix/cache/css/s1/aspro-digital/template_1c7ee19558afd339a21ce4aa5bcef9a7/template_1c7ee19558afd339a21ce4aa5bcef9a7_v1.css?1553013910521373" type="text/css" data-template-style="true" rel="stylesheet" />

    <link rel="shortcut icon" href="/favicon.ico?1536072623" type="image/x-icon" />
    <link rel="apple-touch-icon" sizes="180x180" href="/upload/CDigital/f08/f08cb8b94093da40f4191bf2f4504d6e.png" />
    <style>
        .maxwidth-banner {
            max-width: auto;
        }
    </style>
    <meta property="og:type" content="website" />
    <meta property="og:image" content="/logo.png" />
    <link rel="image_src" href="/logo.png" />
    <meta property="og:url" content="/company/index.php" />
    <meta property="og:description" content="Компания CentrLP —  студия разработки и вредрения веб-решений на 1С-Битрикс с последующим их продвижением и сопровождением." />

</head>

<body class=" fill_bg_n footer-v1 mheader-v1 header-v1 title-v3 with_cabinet with_phones">
    <div id="panel"></div>
    <div id="bxdynamic_options-block_start" style="display:none"></div>
    <div id="bxdynamic_options-block_end" style="display:none"></div>

    <div class="visible-lg visible-md title-v3">
        <div class="top-block top-block-v1">
            <div class="maxwidth-theme">
                <div class="top-block-item col-md-4">
                    <div class="phone-block">
                        <div class="inline-block">
                            <div class="phone">
                                <i class="svg svg-phone"></i>
                                <a href="tel:+79058248564">+7 (905) 824-85-64</a>
                            </div>
                        </div>
                        <div class="inline-block">
                            <span class="callback-block animate-load twosmallfont colored" data-event="jqm" data-param-id="103" data-name="callback">Заказать звонок</span>
                        </div>
                    </div>
                </div>
                <div class="top-block-item pull-left">
                    <div class="address twosmallfont inline-block">
                        <i class="svg svg-address black"></i>
                        <a href="mailto:1@centrlp.ru">1@centrlp.ru</a> </div>
                </div>
                <div class="top-block-item pull-right show-fixed top-ctrl">
                    <button class="top-btn inline-search-show twosmallfont">
                        <i class="svg inline  svg-inline-search" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17">
  <defs>
    <style>
      .sscls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path class="sscls-1" d="M7.5,0A7.5,7.5,0,1,1,0,7.5,7.5,7.5,0,0,1,7.5,0Zm0,2A5.5,5.5,0,1,1,2,7.5,5.5,5.5,0,0,1,7.5,2Z"/>
  <path class="sscls-1" d="M13.417,12.035l3.3,3.3a0.978,0.978,0,1,1-1.382,1.382l-3.3-3.3A0.978,0.978,0,0,1,13.417,12.035Z"/>
</svg>
</i> <span class="dark-color">Поиск</span>
                    </button>
                </div>

                <div class="top-block-item pull-right show-fixed top-ctrl">
                    <div class="personal_wrap">
                        <div class="personal top login twosmallfont">
                            <div id="bxdynamic_cabinet-link1_start" style="display:none"></div>
                            <div id="bxdynamic_cabinet-link1_end" style="display:none"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <header class="header-v1 topmenu-LIGHT canfixed">
            <div class="logo_and_menu-row">
                <div class="logo-row row">
                    <div class="maxwidth-theme">
                        <div class="logo-block col-md-2 col-sm-3">
                            <div class="logo">
                                <a href="/"><img src="/upload/CDigital/dd3/dd3e5beb9541a4b49f4c412880da3121.png" alt="CentrLP" title="CentrLP" /></a>
                            </div>
                        </div>
                        <div class="col-md-2 hidden-sm hidden-xs">
                            <div class="top-description">
                                Сайты, SMM, Дизайн, Чат-бот<br>Комплексный маркетинг </div>
                        </div>
                        <div class="col-md-8 menu-row">
                            <div class="nav-main-collapse collapse in">
                                <div class="menu-only">
                                    <nav class="mega-menu sliced">
                                        <div class="table-menu">
                                            <div class="marker-nav"></div>
                                            <table>
                                                <tr>

                                                    <td class="menu-item unvisible dropdown  ">
                                                        <div class="wrap">
                                                            <a class="dropdown-toggle" href="/services/">
								Услуги								<div class="line-wrapper"><span class="line"></span></div>
							</a>
                                                            <span class="tail"></span>
                                                            <ul class="dropdown-menu">
                                                                <li class="dropdown-submenu ">
                                                                    <a href="/services/razrabatyvaem/" title="Разработка сайтов">Разработка сайтов<span class="arrow"><i></i></span></a>
                                                                    <ul class="dropdown-menu">
                                                                        <li class=" ">
                                                                            <a href="/services/razrabatyvaem/sayty-vizitki/" title="Сайты-визитки">Сайты-визитки</a>
                                                                        </li>
                                                                        <li class=" ">
                                                                            <a href="/services/razrabatyvaem/korporativnye-sayty/" title="Корпоративные сайты">Корпоративные сайты</a>
                                                                        </li>
                                                                        <li class=" ">
                                                                            <a href="/services/razrabatyvaem/internet-magaziny/" title="Интернет-магазины">Интернет-магазины</a>
                                                                        </li>
                                                                    </ul>
                                                                </li>
                                                                <li class="dropdown-submenu ">
                                                                    <a href="/services/prodvigaem/" title="SMM и соцсети">SMM и соцсети<span class="arrow"><i></i></span></a>
                                                                    <ul class="dropdown-menu">
                                                                        <li class=" ">
                                                                            <a href="/services/prodvigaem/prodvinutoe-seo/" title="Вконтакте">Вконтакте</a>
                                                                        </li>
                                                                        <li class=" ">
                                                                            <a href="/services/prodvigaem/bazovoe-seo/" title="Инстаграм">Инстаграм</a>
                                                                        </li>
                                                                        <li class=" ">
                                                                            <a href="/services/prodvigaem/neyming/" title="Чат-боты">Чат-боты</a>
                                                                        </li>
                                                                    </ul>
                                                                </li>
                                                                <li class="dropdown-submenu ">
                                                                    <a href="/services/povyshaem-effektivnost/" title="Интернет реклама">Интернет реклама<span class="arrow"><i></i></span></a>
                                                                    <ul class="dropdown-menu">
                                                                        <li class=" ">
                                                                            <a href="/services/povyshaem-effektivnost/seo-audit/" title="Яндекс директ">Яндекс директ</a>
                                                                        </li>
                                                                        <li class=" ">
                                                                            <a href="/services/povyshaem-effektivnost/tekhnicheskiy-audit/" title="Google AdWords">Google AdWords</a>
                                                                        </li>
                                                                        <li class=" ">
                                                                            <a href="/services/povyshaem-effektivnost/audit-kommercheskikh-faktorov/" title="SEO продвижение">SEO продвижение</a>
                                                                        </li>
                                                                        <li class=" ">
                                                                            <a href="/services/povyshaem-effektivnost/integratsiya-s-1s/" title="Партизанский маркетинг">Партизанский маркетинг</a>
                                                                        </li>
                                                                    </ul>
                                                                </li>
                                                                <li class="dropdown-submenu ">
                                                                    <a href="/services/soprovozhdaem/" title="Дизайн">Дизайн<span class="arrow"><i></i></span></a>
                                                                    <ul class="dropdown-menu">
                                                                        <li class=" ">
                                                                            <a href="/services/soprovozhdaem/informatsionnaya-podderzhka/" title="Логотипы и фирменный стиль">Логотипы и фирменный стиль</a>
                                                                        </li>
                                                                        <li class=" ">
                                                                            <a href="/services/soprovozhdaem/tekhnicheskaya-podderzhka/" title="Оформление соцсетей">Оформление соцсетей</a>
                                                                        </li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </td>

                                                    <td class="menu-item unvisible dropdown  ">
                                                        <div class="wrap">
                                                            <a class="dropdown-toggle" href="/projects/">
								Портфолио								<div class="line-wrapper"><span class="line"></span></div>
							</a>
                                                            <span class="tail"></span>
                                                            <ul class="dropdown-menu">
                                                                <li class=" ">
                                                                    <a href="/projects/internet-magaziny/" title="Интернет-магазины">Интернет-магазины</a>
                                                                </li>
                                                                <li class=" ">
                                                                    <a href="/projects/sayty-vizitki/" title="Сайты визитки">Сайты визитки</a>
                                                                </li>
                                                                <li class=" ">
                                                                    <a href="/projects/gotovye-resheniya/" title="Готовые решения">Готовые решения</a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </td>

                                                    <td class="menu-item unvisible   ">
                                                        <div class="wrap">
                                                            <a class="" href="/articles/">
								Блог								<div class="line-wrapper"><span class="line"></span></div>
							</a>
                                                        </div>
                                                    </td>

                                                    <td class="menu-item unvisible dropdown  active">
                                                        <div class="wrap">
                                                            <a class="dropdown-toggle" href="/company/">
								Компания								<div class="line-wrapper"><span class="line"></span></div>
							</a>
                                                            <span class="tail"></span>
                                                            <ul class="dropdown-menu">
                                                                <li class=" active">
                                                                    <a href="/company/index.php" title="О компании">О компании</a>
                                                                </li>
                                                                <li class=" ">
                                                                    <a href="/company/licenses/" title="Сертификаты">Сертификаты</a>
                                                                </li>
                                                                <li class=" ">
                                                                    <a href="/company/requisites/" title="Реквизиты">Реквизиты</a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </td>

                                                    <td class="menu-item unvisible   ">
                                                        <div class="wrap">
                                                            <a class="" href="/contacts/">
								Контакты								<div class="line-wrapper"><span class="line"></span></div>
							</a>
                                                        </div>
                                                    </td>

                                                    <td class="dropdown js-dropdown nosave unvisible">
                                                        <div class="wrap">
                                                            <a class="dropdown-toggle more-items" href="#">
                                                                <span>Ещё</span>
                                                            </a>
                                                            <span class="tail"></span>
                                                            <ul class="dropdown-menu"></ul>
                                                        </div>
                                                    </td>

                                                </tr>
                                            </table>
                                        </div>

                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="line-row visible-xs"></div>
        </header>
    </div>

    <div id="headerfixed">
        <div class="maxwidth-theme">
            <div class="logo-row v2 row margin0">
                <div class="inner-table-block nopadding logo-block">
                    <div class="logo">
                        <a href="/"><img src="/upload/CDigital/dd3/dd3e5beb9541a4b49f4c412880da3121.png" alt="CentrLP" title="CentrLP" /></a>
                    </div>
                </div>
                <div class="inner-table-block menu-block">
                    <div class="navs table-menu js-nav">
                        <nav class="mega-menu sliced">
                            <div class="table-menu">
                                <div class="marker-nav"></div>
                                <table>
                                    <tr>

                                        <td class="menu-item unvisible dropdown  ">
                                            <div class="wrap">
                                                <a class="dropdown-toggle" href="/services/">
								Услуги								<div class="line-wrapper"><span class="line"></span></div>
							</a>
                                                <span class="tail"></span>
                                                <ul class="dropdown-menu">
                                                    <li class="dropdown-submenu ">
                                                        <a href="/services/razrabatyvaem/" title="Разработка сайтов">Разработка сайтов<span class="arrow"><i></i></span></a>
                                                        <ul class="dropdown-menu">
                                                            <li class=" ">
                                                                <a href="/services/razrabatyvaem/sayty-vizitki/" title="Сайты-визитки">Сайты-визитки</a>
                                                            </li>
                                                            <li class=" ">
                                                                <a href="/services/razrabatyvaem/korporativnye-sayty/" title="Корпоративные сайты">Корпоративные сайты</a>
                                                            </li>
                                                            <li class=" ">
                                                                <a href="/services/razrabatyvaem/internet-magaziny/" title="Интернет-магазины">Интернет-магазины</a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li class="dropdown-submenu ">
                                                        <a href="/services/prodvigaem/" title="SMM и соцсети">SMM и соцсети<span class="arrow"><i></i></span></a>
                                                        <ul class="dropdown-menu">
                                                            <li class=" ">
                                                                <a href="/services/prodvigaem/prodvinutoe-seo/" title="Вконтакте">Вконтакте</a>
                                                            </li>
                                                            <li class=" ">
                                                                <a href="/services/prodvigaem/bazovoe-seo/" title="Инстаграм">Инстаграм</a>
                                                            </li>
                                                            <li class=" ">
                                                                <a href="/services/prodvigaem/neyming/" title="Чат-боты">Чат-боты</a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li class="dropdown-submenu ">
                                                        <a href="/services/povyshaem-effektivnost/" title="Интернет реклама">Интернет реклама<span class="arrow"><i></i></span></a>
                                                        <ul class="dropdown-menu">
                                                            <li class=" ">
                                                                <a href="/services/povyshaem-effektivnost/seo-audit/" title="Яндекс директ">Яндекс директ</a>
                                                            </li>
                                                            <li class=" ">
                                                                <a href="/services/povyshaem-effektivnost/tekhnicheskiy-audit/" title="Google AdWords">Google AdWords</a>
                                                            </li>
                                                            <li class=" ">
                                                                <a href="/services/povyshaem-effektivnost/audit-kommercheskikh-faktorov/" title="SEO продвижение">SEO продвижение</a>
                                                            </li>
                                                            <li class=" ">
                                                                <a href="/services/povyshaem-effektivnost/integratsiya-s-1s/" title="Партизанский маркетинг">Партизанский маркетинг</a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li class="dropdown-submenu ">
                                                        <a href="/services/soprovozhdaem/" title="Дизайн">Дизайн<span class="arrow"><i></i></span></a>
                                                        <ul class="dropdown-menu">
                                                            <li class=" ">
                                                                <a href="/services/soprovozhdaem/informatsionnaya-podderzhka/" title="Логотипы и фирменный стиль">Логотипы и фирменный стиль</a>
                                                            </li>
                                                            <li class=" ">
                                                                <a href="/services/soprovozhdaem/tekhnicheskaya-podderzhka/" title="Оформление соцсетей">Оформление соцсетей</a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>

                                        <td class="menu-item unvisible dropdown  ">
                                            <div class="wrap">
                                                <a class="dropdown-toggle" href="/projects/">
								Портфолио								<div class="line-wrapper"><span class="line"></span></div>
							</a>
                                                <span class="tail"></span>
                                                <ul class="dropdown-menu">
                                                    <li class=" ">
                                                        <a href="/projects/internet-magaziny/" title="Интернет-магазины">Интернет-магазины</a>
                                                    </li>
                                                    <li class=" ">
                                                        <a href="/projects/sayty-vizitki/" title="Сайты визитки">Сайты визитки</a>
                                                    </li>
                                                    <li class=" ">
                                                        <a href="/projects/gotovye-resheniya/" title="Готовые решения">Готовые решения</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>

                                        <td class="menu-item unvisible   ">
                                            <div class="wrap">
                                                <a class="" href="/articles/">
								Блог								<div class="line-wrapper"><span class="line"></span></div>
							</a>
                                            </div>
                                        </td>

                                        <td class="menu-item unvisible dropdown  active">
                                            <div class="wrap">
                                                <a class="dropdown-toggle" href="/company/">
								Компания								<div class="line-wrapper"><span class="line"></span></div>
							</a>
                                                <span class="tail"></span>
                                                <ul class="dropdown-menu">
                                                    <li class=" active">
                                                        <a href="/company/index.php" title="О компании">О компании</a>
                                                    </li>
                                                    <li class=" ">
                                                        <a href="/company/licenses/" title="Сертификаты">Сертификаты</a>
                                                    </li>
                                                    <li class=" ">
                                                        <a href="/company/requisites/" title="Реквизиты">Реквизиты</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>

                                        <td class="menu-item unvisible   ">
                                            <div class="wrap">
                                                <a class="" href="/contacts/">
								Контакты								<div class="line-wrapper"><span class="line"></span></div>
							</a>
                                            </div>
                                        </td>

                                        <td class="dropdown js-dropdown nosave unvisible">
                                            <div class="wrap">
                                                <a class="dropdown-toggle more-items" href="#">
                                                    <span>Ещё</span>
                                                </a>
                                                <span class="tail"></span>
                                                <ul class="dropdown-menu"></ul>
                                            </div>
                                        </td>

                                    </tr>
                                </table>
                            </div>

                        </nav>
                    </div>
                </div>
                <div class="inner-table-block nopadding small-block">
                    <div class="wrap_icon wrap_cabinet">
                        <div id="bxdynamic_cabinet-link2_start" style="display:none"></div>
                        <div id="bxdynamic_cabinet-link2_end" style="display:none"></div>
                    </div>
                </div>
                <div id="bxdynamic_basket-link1_start" style="display:none"></div>
                <div id="bxdynamic_basket-link1_end" style="display:none"></div>
                <div class="inner-table-block small-block nopadding inline-search-show" data-type_search="fixed">
                    <div class="search-block top-btn"><i class="svg svg-search lg"></i></div>
                </div>
            </div>
        </div>
    </div>

    <div id="mobileheader" class="visible-xs visible-sm">
        <div class="mobileheader-v1">
            <div class="burger pull-left">
                <i class="svg inline  svg-inline-burger dark" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="16" viewBox="0 0 18 16">
  <defs>
    <style>
      .cls-1 {
        fill: #fff;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 81 copy 2" class="cls-1" d="M330,114h16a1,1,0,0,1,1,1h0a1,1,0,0,1-1,1H330a1,1,0,0,1-1-1h0A1,1,0,0,1,330,114Zm0,7h16a1,1,0,0,1,1,1h0a1,1,0,0,1-1,1H330a1,1,0,0,1-1-1h0A1,1,0,0,1,330,121Zm0,7h16a1,1,0,0,1,1,1h0a1,1,0,0,1-1,1H330a1,1,0,0,1-1-1h0A1,1,0,0,1,330,128Z" transform="translate(-329 -114)"/>
</svg>
</i> <i class="svg inline  svg-inline-close dark" aria-hidden="true"><svg id="Close.svg" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path id="Rounded_Rectangle_114_copy_3" data-name="Rounded Rectangle 114 copy 3" class="cls-1" d="M334.411,138l6.3,6.3a1,1,0,0,1,0,1.414,0.992,0.992,0,0,1-1.408,0l-6.3-6.306-6.3,6.306a1,1,0,0,1-1.409-1.414l6.3-6.3-6.293-6.3a1,1,0,0,1,1.409-1.414l6.3,6.3,6.3-6.3A1,1,0,0,1,340.7,131.7Z" transform="translate(-325 -130)"/>
</svg>
</i> </div>
            <div class="logo-block pull-left">
                <div class="logo">
                    <a href="/"><img src="/upload/CDigital/dd3/dd3e5beb9541a4b49f4c412880da3121.png" alt="CentrLP" title="CentrLP" /></a>
                </div>
            </div>
            <div class="right-icons pull-right">
                <div class="pull-right">
                    <div class="wrap_icon">
                        <button class="top-btn inline-search-show twosmallfont">
                            <i class="svg inline  svg-inline-search" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 106" class="cls-1" d="M1590.71,131.709a1,1,0,0,1-1.42,0l-4.68-4.677a9.069,9.069,0,1,1,1.42-1.427l4.68,4.678A1,1,0,0,1,1590.71,131.709ZM1579,113a7,7,0,1,0,7,7A7,7,0,0,0,1579,113Z" transform="translate(-1570 -111)"/>
</svg>
</i> </button>
                    </div>
                </div>
                <div class="pull-right">
                    <div class="wrap_icon wrap_basket">
                        <div id="bxdynamic_basket-link2_start" style="display:none"></div>
                        <div id="bxdynamic_basket-link2_end" style="display:none"></div>
                    </div>
                </div>
                <div class="pull-right">
                    <div class="wrap_icon wrap_cabinet">
                        <div id="bxdynamic_cabinet-link3_start" style="display:none"></div>
                        <div id="bxdynamic_cabinet-link3_end" style="display:none"></div>
                    </div>
                </div>
            </div>
        </div>
        <div id="mobilemenu" class="leftside">
            <div class="mobilemenu-v1 scroller">
                <div class="wrap">
                    <div class="menu top">
                        <ul class="top">
                            <li>
                                <a class="dark-color parent" href="/services/" title="Услуги">
                                    <span>Услуги</span>
                                    <span class="arrow"><i class="svg svg_triangle_right"></i></span>
                                </a>
                                <ul class="dropdown">
                                    <li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg svg-arrow-right"></i>Назад</a></li>
                                    <li class="menu_title"><a href="/services/">Услуги</a></li>
                                    <li>
                                        <a class="dark-color parent" href="/services/razrabatyvaem/" title="Разработка сайтов">
                                            <span>Разработка сайтов</span>
                                            <span class="arrow"><i class="svg svg_triangle_right"></i></span>
                                        </a>
                                        <ul class="dropdown">
                                            <li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg svg-arrow-right"></i>Назад</a></li>
                                            <li class="menu_title"><a href="/services/razrabatyvaem/">Разработка сайтов</a></li>
                                            <li>
                                                <a class="dark-color" href="/services/razrabatyvaem/sayty-vizitki/" title="Сайты-визитки">
                                                    <span>Сайты-визитки</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dark-color" href="/services/razrabatyvaem/korporativnye-sayty/" title="Корпоративные сайты">
                                                    <span>Корпоративные сайты</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dark-color" href="/services/razrabatyvaem/internet-magaziny/" title="Интернет-магазины">
                                                    <span>Интернет-магазины</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a class="dark-color parent" href="/services/prodvigaem/" title="SMM и соцсети">
                                            <span>SMM и соцсети</span>
                                            <span class="arrow"><i class="svg svg_triangle_right"></i></span>
                                        </a>
                                        <ul class="dropdown">
                                            <li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg svg-arrow-right"></i>Назад</a></li>
                                            <li class="menu_title"><a href="/services/prodvigaem/">SMM и соцсети</a></li>
                                            <li>
                                                <a class="dark-color" href="/services/prodvigaem/prodvinutoe-seo/" title="Вконтакте">
                                                    <span>Вконтакте</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dark-color" href="/services/prodvigaem/bazovoe-seo/" title="Инстаграм">
                                                    <span>Инстаграм</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dark-color" href="/services/prodvigaem/neyming/" title="Чат-боты">
                                                    <span>Чат-боты</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a class="dark-color parent" href="/services/povyshaem-effektivnost/" title="Интернет реклама">
                                            <span>Интернет реклама</span>
                                            <span class="arrow"><i class="svg svg_triangle_right"></i></span>
                                        </a>
                                        <ul class="dropdown">
                                            <li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg svg-arrow-right"></i>Назад</a></li>
                                            <li class="menu_title"><a href="/services/povyshaem-effektivnost/">Интернет реклама</a></li>
                                            <li>
                                                <a class="dark-color" href="/services/povyshaem-effektivnost/seo-audit/" title="Яндекс директ">
                                                    <span>Яндекс директ</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dark-color" href="/services/povyshaem-effektivnost/tekhnicheskiy-audit/" title="Google AdWords">
                                                    <span>Google AdWords</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dark-color" href="/services/povyshaem-effektivnost/audit-kommercheskikh-faktorov/" title="SEO продвижение">
                                                    <span>SEO продвижение</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dark-color" href="/services/povyshaem-effektivnost/integratsiya-s-1s/" title="Партизанский маркетинг">
                                                    <span>Партизанский маркетинг</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a class="dark-color parent" href="/services/soprovozhdaem/" title="Дизайн">
                                            <span>Дизайн</span>
                                            <span class="arrow"><i class="svg svg_triangle_right"></i></span>
                                        </a>
                                        <ul class="dropdown">
                                            <li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg svg-arrow-right"></i>Назад</a></li>
                                            <li class="menu_title"><a href="/services/soprovozhdaem/">Дизайн</a></li>
                                            <li>
                                                <a class="dark-color" href="/services/soprovozhdaem/informatsionnaya-podderzhka/" title="Логотипы и фирменный стиль">
                                                    <span>Логотипы и фирменный стиль</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dark-color" href="/services/soprovozhdaem/tekhnicheskaya-podderzhka/" title="Оформление соцсетей">
                                                    <span>Оформление соцсетей</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a class="dark-color parent" href="/projects/" title="Портфолио">
                                    <span>Портфолио</span>
                                    <span class="arrow"><i class="svg svg_triangle_right"></i></span>
                                </a>
                                <ul class="dropdown">
                                    <li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg svg-arrow-right"></i>Назад</a></li>
                                    <li class="menu_title"><a href="/projects/">Портфолио</a></li>
                                    <li>
                                        <a class="dark-color" href="/projects/internet-magaziny/" title="Интернет-магазины">
                                            <span>Интернет-магазины</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dark-color" href="/projects/sayty-vizitki/" title="Сайты визитки">
                                            <span>Сайты визитки</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dark-color" href="/projects/gotovye-resheniya/" title="Готовые решения">
                                            <span>Готовые решения</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a class="dark-color" href="/articles/" title="Блог">
                                    <span>Блог</span>
                                </a>
                            </li>
                            <li class="selected">
                                <a class="dark-color parent" href="/company/" title="Компания">
                                    <span>Компания</span>
                                    <span class="arrow"><i class="svg svg_triangle_right"></i></span>
                                </a>
                                <ul class="dropdown">
                                    <li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg svg-arrow-right"></i>Назад</a></li>
                                    <li class="menu_title"><a href="/company/">Компания</a></li>
                                    <li class="selected">
                                        <a class="dark-color" href="/company/index.php" title="О компании">
                                            <span>О компании</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dark-color" href="/company/licenses/" title="Сертификаты">
                                            <span>Сертификаты</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dark-color" href="/company/requisites/" title="Реквизиты">
                                            <span>Реквизиты</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a class="dark-color" href="/contacts/" title="Контакты">
                                    <span>Контакты</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="menu middle">
                        <ul>
                            <li>
                                <a class="dark-color" href="/cabinet/">
                                    <i class="svg inline  svg-inline-cabinet" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17">
  <defs>
    <style>
      .loccls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path class="loccls-1" d="M14,17H2a2,2,0,0,1-2-2V8A2,2,0,0,1,2,6H3V4A4,4,0,0,1,7,0H9a4,4,0,0,1,4,4V6h1a2,2,0,0,1,2,2v7A2,2,0,0,1,14,17ZM11,4A2,2,0,0,0,9,2H7A2,2,0,0,0,5,4V6h6V4Zm3,4H2v7H14V8ZM8,9a1,1,0,0,1,1,1v2a1,1,0,0,1-2,0V10A1,1,0,0,1,8,9Z"/>
</svg>
</i> <span>Личный кабинет</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="menu middle">
                        <ul>
                            <li>
                                <a href="tel:+79058248564" class="dark-color">
                                    <i class="svg svg-phone"></i>
                                    <span>+7 (905) 824-85-64</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="contacts">
                        <div class="title">Будьте на связи</div>
                        <div class="address">
                            <i class="svg inline  svg-inline-address" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="13" height="16" viewBox="0 0 13 16">
  <defs>
    <style>
      .acls-1 {
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Ellipse 74 copy" class="acls-1" d="M763.9,42.916h0.03L759,49h-1l-4.933-6.084h0.03a6.262,6.262,0,0,1-1.1-3.541,6.5,6.5,0,0,1,13,0A6.262,6.262,0,0,1,763.9,42.916ZM758.5,35a4.5,4.5,0,0,0-3.741,7h-0.012l3.542,4.447h0.422L762.289,42H762.24A4.5,4.5,0,0,0,758.5,35Zm0,6a1.5,1.5,0,1,1,1.5-1.5A1.5,1.5,0,0,1,758.5,41Z" transform="translate(-752 -33)"/>
</svg>
</i> <a href="mailto:1@centrlp.ru">1@centrlp.ru</a> </div>
                        <div class="email">
                            <i class="svg inline  svg-inline-email" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="13" viewBox="0 0 16 13">
  <defs>
    <style>
      .ecls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path class="ecls-1" d="M14,13H2a2,2,0,0,1-2-2V2A2,2,0,0,1,2,0H14a2,2,0,0,1,2,2v9A2,2,0,0,1,14,13ZM3.534,2L8.015,6.482,12.5,2H3.534ZM14,3.5L8.827,8.671a1.047,1.047,0,0,1-.812.3,1.047,1.047,0,0,1-.811-0.3L2,3.467V11H14V3.5Z"/>
</svg>
</i> <a href="mailto:1@centrlp.ru">1@centrlp.ru</a> </div>
                    </div>
                    <div class="social-icons">
                        <!-- noindex -->
                        <ul>
                            <li class="instagram">
                                <a href="https://www.instagram.com/centrlp/" class="dark-color" target="_blank" rel="nofollow" title="Instagram">
                                    <i class="svg inline  svg-inline-inst" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path class="cls-1" d="M13,17H7a4,4,0,0,1-4-4V7A4,4,0,0,1,7,3h6a4,4,0,0,1,4,4v6A4,4,0,0,1,13,17ZM15,7a2,2,0,0,0-2-2H7A2,2,0,0,0,5,7v6a2,2,0,0,0,2,2h6a2,2,0,0,0,2-2V7Zm-5,6a3,3,0,1,1,3-3A3,3,0,0,1,10,13Zm1-4H9v2h2V9Z"/>
</svg>
</i> Instagram </a>
                            </li>
                        </ul>
                        <!-- /noindex -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="body  hover_shine">
        <div class="body_media"></div>

        <div role="main" class="main banner-AUTO">

            <!--title_content-->
            <div class="page-top-wrapper grey v3">
                <section class="page-top maxwidth-theme ">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 id="pagetitle">О компании</h1>
                            <ul class="breadcrumb" id="navigation" itemscope itemtype="http://schema.org/BreadcrumbList">
                                <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" id="bx_breadcrumb_0"><a href="/" title="Главная" itemscope itemtype="http://schema.org/Thing" itemprop="item"><span itemprop="name">Главная</span></a>
                                    <meta itemprop="position" content="1" />
                                </li>
                                <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" id="bx_breadcrumb_1" class="active"><span itemscope itemtype="http://schema.org/Thing" itemprop="item"><span itemprop="name">О компании</span></span>
                                    <meta itemprop="position" content="2" />
                                </li>
                            </ul>
                        </div>
                    </div>
                </section>
            </div>
            <!--end-title_content-->

            <div class="container ">
                <div class="row">
                    <div class="maxwidth-theme">
                        <div class="col-md-3 col-sm-3 hidden-xs hidden-sm left-menu-md">
                            <aside class="sidebar">
                                <ul class="nav nav-list side-menu">
                                    <li class="active ">
                                        <a href="/company/index.php">О компании</a>
                                    </li>
                                    <li class=" ">
                                        <a href="/company/licenses/">Сертификаты</a>
                                    </li>
                                    <li class=" ">
                                        <a href="/company/requisites/">Реквизиты</a>
                                    </li>
                                </ul>
                            </aside>
                            <div class="sidearea">
                                <div style="padding:0 10px 0 30px;color:#666666;">
                                    <i>Находим решения </i><i>для любой задачи.<br>
 </i><i>Просто расскажите нам о ней!</i>
                                </div>
                                <br> </div>
                        </div>
                        <div class="col-md-9 col-sm-12 col-xs-12 content-md">
                            <p style="text-align: center;">
                                <img width="1245" src="/images/services/proekti/about_img.jpg" height="480" class="img-responsive"> &nbsp;&nbsp;
                            </p>
                            <p>
                                <b>Компания CentrLP</b> — &nbsp;студия разработки и вредрения веб-решений на 1С-Битрикс с последующим их продвижением и сопровождением.
                            </p>
                            <h3>Чем мы можем быть вам полезны</h3>
                            <p>
                            </p>
                            <ul>
                                <li><b>Разрабатываем сайты визитки, корпоративные сайты и интернет-магазины. </b> Делаем это быстро и недорого на основе готовых решений для 1С-Битрикс.
                                    <br>
                                </li>
                                <li><b>Увеличиваем прибыльность вашего бизнеса.</b> Выстраиваем работу сайта в соответствии с особенностями Вашего бизнеса и реализуем удобные коммуникации между клиентами и менеджерами Вашей компании</li>
                                <li><b>Продвигаем сайты.</b> Комплексно анализируем и оптимизируем, ищем проблемные места и исправляем их, делая сайты действительно полезными для посетителей.</li>
                                <li><b>Сами разрабатываем готовые решения. </b> И кое-что в этом понимаем =)</li>
                            </ul>
                            <p>
                            </p>

                            <h3>
<p>
	<b>Компания CentrLP</b><b> — это люди!</b>
</p>
 </h3>
                            <p>
                                SEO-специалисты, программисты, дизайнер и аналитик – всего в нашей дружной команде 6 человек. Мы работаем с каждым клиентом индивидуально, чтобы найти решение каждой задачи. За период работы с 2013 года компания принесла своим постоянным клиентам более 12 миллионов чистой прибыли.
                            </p>

                            <p>
                                <b>Наша работа в цифрах</b>:
                            </p>
                            <ul>
                                <li>
                                    <p>
                                        25+ клиентов на постоянной технической и информационной поддержке.
                                    </p>
                                </li>
                                <li>
                                    <p>
                                        Более 1400 установок наших готовых решений.
                                    </p>
                                </li>
                                <li>
                                    <p>
                                        Около 130 решаемых задач ежемесячно!
                                    </p>
                                </li>
                            </ul>
                            <p>
                                Мы знаем, как выгодно использовать бюджет и как взорвать нишу и рынок вашим предложением. Оставьте заявку на консультацию, посмотрите <a href="/projects/">наше портфолио</a>.
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer id="footer">

        <div class="container">
            <div class="row bottom-middle">
                <div class="maxwidth-theme">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-3 col-sm-3">
                                <div class="bottom-menu">
                                    <div class="items">
                                        <div class="item-link">
                                            <div class="item active">
                                                <div class="title">
                                                    <a href="/company/">Компания</a>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="wrap">
                                            <div class="item-link">
                                                <div class="item active">
                                                    <div class="title">
                                                        <a href="/company/index.php">О компании</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-link">
                                                <div class="item">
                                                    <div class="title">
                                                        <a href="/company/licenses/">Сертификаты</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-link">
                                                <div class="item">
                                                    <div class="title">
                                                        <a href="/company/requisites/">Реквизиты</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3">
                            </div>
                            <div class="col-md-3 col-sm-3">

                                <div class="bottom-menu">
                                    <div class="items">
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a href="/services/">Услуги</a>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="wrap">
                                            <div class="item-link">
                                                <div class="item">
                                                    <div class="title">
                                                        <a href="/services/razrabatyvaem/">Разработка сайтов</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-link">
                                                <div class="item">
                                                    <div class="title">
                                                        <a href="/services/prodvigaem/">SMM и соцсети</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-link">
                                                <div class="item">
                                                    <div class="title">
                                                        <a href="/services/povyshaem-effektivnost/">Интернет реклама</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-link">
                                                <div class="item">
                                                    <div class="title">
                                                        <a href="/services/soprovozhdaem/">Дизайн</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 contact-block">
                        <div class="row">
                            <div class="col-md-9 col-md-offset-2">
                                <span class="white_middle_text">Наши контакты<br>
<br>
<br>
</span>
                                <div class="info">
                                    <div class="row">
                                        <div class="col-md-12 col-sm-4">
                                            <div class="phone blocks">
                                                <a href="tel:+79058248564">+7 (905) 824-85-64</a> </div>
                                        </div>
                                        <div class="col-md-12 col-sm-4">
                                            <div class="email blocks">
                                                <a href="mailto:1@centrlp.ru">1@centrlp.ru</a> </div>
                                        </div>
                                        <div class="col-md-12 col-sm-4">
                                            <div class="address blocks">
                                                <a href="https://go.2gis.com/amjqg" target="_blank">Мы находимся</a> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row bottom-under">
                <div class="maxwidth-theme">
                    <div class="col-md-12 outer-wrapper">
                        <div class="inner-wrapper">
                            <div class="copy-block">
                                <div class="copy">
                                    &copy; 2019 <a href="/">Разработка и продвижение сайтов в Тюмени</a> - CentrLP.
                                    <br>
                                    <a href="/agreement/">Пользовательское соглашение</a>
                                    <br> Отправляя свои персональные данные через формы сайта Вы соглашаетесь с <a href="/include/licenses_detail.php">политикой конфиденциальности</a> </div>
                                <div class="print-block"></div>
                                <div id="bx-composite-banner"></div>
                            </div>
                            <div class="social-block">
                                <div class="social-icons">
                                    <!-- noindex -->
                                    <ul>
                                        <li class="instagram">
                                            <a href="https://www.instagram.com/centrlp/" target="_blank" rel="nofollow" title="Instagram">
					Instagram				</a>
                                        </li>
                                    </ul>
                                    <!-- /noindex -->
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="bx_areas">
        <!-- Yandex.Metrika counter -->
        <!-- /Yandex.Metrika counter -->

    </div>

    <div class="inline-search-block fixed with-close big">
        <div class="maxwidth-theme">
            <div class="col-md-12">
                <div class="search-wrapper">
                    <div id="title-search">
                        <form action="/search/" class="search">
                            <div class="search-input-div">
                                <input class="search-input" id="title-search-input" type="text" name="q" value="" placeholder="Найти" size="40" maxlength="50" autocomplete="off" />
                            </div>
                            <div class="search-button-div">
                                <button class="btn btn-search btn-default bold btn-lg" type="submit" name="s" value="Найти">Найти</button>
                                <span class="close-block inline-search-hide"><span class="svg svg-close close-icons"></span></span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- noindex -->
    <div class="ajax_basket">
    </div>
    <!-- /noindex -->

    <script type="text/javascript">
        if (!window.BX) window.BX = {};
        if (!window.BX.message) window.BX.message = function(mess) {
            if (typeof mess == 'object')
                for (var i in mess) BX.message[i] = mess[i];
            return true;
        };
    </script>
    <script type="text/javascript">
        (window.BX || top.BX).message({
            'JS_CORE_LOADING': 'Загрузка...',
            'JS_CORE_NO_DATA': '- Нет данных -',
            'JS_CORE_WINDOW_CLOSE': 'Закрыть',
            'JS_CORE_WINDOW_EXPAND': 'Развернуть',
            'JS_CORE_WINDOW_NARROW': 'Свернуть в окно',
            'JS_CORE_WINDOW_SAVE': 'Сохранить',
            'JS_CORE_WINDOW_CANCEL': 'Отменить',
            'JS_CORE_WINDOW_CONTINUE': 'Продолжить',
            'JS_CORE_H': 'ч',
            'JS_CORE_M': 'м',
            'JS_CORE_S': 'с',
            'JSADM_AI_HIDE_EXTRA': 'Скрыть лишние',
            'JSADM_AI_ALL_NOTIF': 'Показать все',
            'JSADM_AUTH_REQ': 'Требуется авторизация!',
            'JS_CORE_WINDOW_AUTH': 'Войти',
            'JS_CORE_IMAGE_FULL': 'Полный размер'
        });
    </script>
    <script type="text/javascript">
        (window.BX || top.BX).message({
            'LANGUAGE_ID': 'ru',
            'FORMAT_DATE': 'DD.MM.YYYY',
            'FORMAT_DATETIME': 'DD.MM.YYYY HH:MI:SS',
            'COOKIE_PREFIX': 'BITRIX_SM',
            'SERVER_TZ_OFFSET': '10800',
            'SITE_ID': 's1',
            'SITE_DIR': '/'
        });
    </script>
    <script type="text/javascript" src="/bitrix/cache/js/s1/aspro-digital/kernel_main/kernel_main_v1.js?1553013998310274"></script>
    <script type="text/javascript" src="/bitrix/cache/js/s1/aspro-digital/kernel_main_polyfill_promise/kernel_main_polyfill_promise_v1.js?15530139102506"></script>
    <script type="text/javascript" src="/bitrix/js/main/loadext/loadext.min.js?1543329375810"></script>
    <script type="text/javascript" src="/bitrix/js/main/loadext/extension.min.js?15433293751304"></script>
    <script type="text/javascript" src="/bitrix/js/main/core/core_db.min.js?153543147410247"></script>
    <script type="text/javascript" src="/bitrix/js/main/core/core_frame_cache.min.js?153572805511334"></script>
    <script type="text/javascript" src="/bitrix/js/main/jquery/jquery-2.1.3.min.js?149546441484320"></script>
    <script type="text/javascript" src="/bitrix/js/main/ajax.min.js?149546441422194"></script>
    <script type="text/javascript">
        BX.setJSList(['/bitrix/js/main/core/core.js', '/bitrix/js/main/core/core_promise.js', '/bitrix/js/main/core/core_ajax.js', '/bitrix/js/main/json/json2.min.js', '/bitrix/js/main/core/core_ls.js', '/bitrix/js/main/core/core_fx.js', '/bitrix/js/main/session.js', '/bitrix/js/main/core/core_window.js', '/bitrix/js/main/core/core_popup.js', '/bitrix/js/main/core/core_date.js', '/bitrix/js/main/utils.js', '/bitrix/js/main/polyfill/promise/js/promise.js', '/bitrix/templates/aspro-digital/js/jquery.actual.min.js', '/bitrix/templates/aspro-digital/js/jquery.fancybox.js', '/bitrix/templates/aspro-digital/vendor/jquery.easing.js', '/bitrix/templates/aspro-digital/vendor/jquery.appear.js', '/bitrix/templates/aspro-digital/vendor/jquery.cookie.js', '/bitrix/templates/aspro-digital/vendor/bootstrap.js', '/bitrix/templates/aspro-digital/vendor/flexslider/jquery.flexslider.min.js', '/bitrix/templates/aspro-digital/vendor/jquery.validate.min.js', '/bitrix/templates/aspro-digital/js/jquery.uniform.min.js', '/bitrix/templates/aspro-digital/js/jqModal.js', '/bitrix/templates/aspro-digital/js/detectmobilebrowser.js', '/bitrix/templates/aspro-digital/js/matchMedia.js', '/bitrix/templates/aspro-digital/js/jquery.waypoints.min.js', '/bitrix/templates/aspro-digital/js/jquery.counterup.js', '/bitrix/templates/aspro-digital/js/jquery.alphanumeric.js', '/bitrix/templates/aspro-digital/js/jquery.mobile.custom.touch.min.js', '/bitrix/templates/aspro-digital/js/general.js', '/bitrix/templates/aspro-digital/js/custom.js', '/bitrix/components/bitrix/search.title/script.js', '/bitrix/templates/aspro-digital/components/bitrix/search.title/fixed/script.js', '/bitrix/templates/aspro-digital/js/lazyload.min.js', '/bitrix/templates/aspro-digital/js/jquery.inputmask.bundle.min.js']);
    </script>
    <script type="text/javascript">
        BX.setCSSList(['/bitrix/js/main/core/css/core.css', '/bitrix/js/main/core/css/core_popup.css', '/bitrix/js/main/core/css/core_date.css', '/bitrix/templates/aspro-digital/css/bootstrap.css', '/bitrix/templates/aspro-digital/css/fonts/font-awesome/css/font-awesome.min.css', '/bitrix/templates/aspro-digital/vendor/flexslider/flexslider.css', '/bitrix/templates/aspro-digital/css/jquery.fancybox.css', '/bitrix/templates/aspro-digital/css/theme-elements.css', '/bitrix/templates/aspro-digital/css/theme-responsive.css', '/bitrix/templates/aspro-digital/css/print.css', '/bitrix/templates/aspro-digital/css/animation/animate.min.css', '/bitrix/templates/aspro-digital/css/animation/animation_ext.css', '/bitrix/templates/aspro-digital/css/h1-normal.css', '/bitrix/templates/.default/ajax/ajax.css', '/bitrix/templates/aspro-digital/css/width-3.css', '/bitrix/templates/aspro-digital/css/font-1.css', '/bitrix/templates/aspro-digital/styles.css', '/bitrix/templates/aspro-digital/template_styles.css', '/bitrix/templates/aspro-digital/css/responsive.css', '/bitrix/templates/aspro-digital/themes/4/colors.css', '/bitrix/templates/aspro-digital/bg_color/light/bgcolors.css', '/bitrix/templates/aspro-digital/css/custom.css']);
    </script>
    <script type="text/javascript">
        var bxDate = new Date();
        document.cookie = "BITRIX_SM_TIME_ZONE=" + bxDate.getTimezoneOffset() + "; path=/; expires=Fri, 01-Jan-2038 00:00:00 GMT"
    </script>
    <script type="text/javascript">
        (function() {
            "use strict";

            var counter = function() {
                var cookie = (function(name) {
                    var parts = ("; " + document.cookie).split("; " + name + "=");
                    if (parts.length == 2) {
                        try {
                            return JSON.parse(decodeURIComponent(parts.pop().split(";").shift()));
                        } catch (e) {}
                    }
                })("BITRIX_CONVERSION_CONTEXT_s1");

                if (cookie && cookie.EXPIRE >= BX.message("SERVER_TIME"))
                    return;

                var request = new XMLHttpRequest();
                request.open("POST", "/bitrix/tools/conversion/ajax_counter.php", true);
                request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                request.send(
                    "SITE_ID=" + encodeURIComponent("s1") +
                    "&sessid=" + encodeURIComponent(BX.bitrix_sessid()) +
                    "&HTTP_REFERER=" + encodeURIComponent(document.referrer)
                );
            };

            if (window.frameRequestStart === true)
                BX.addCustomEvent("onFrameDataReceived", counter);
            else
                BX.ready(counter);
        })();
    </script>
    <script>
        BX.message({
            'JS_REQUIRED': 'Заполните это поле!',
            'JS_FORMAT': 'Неверный формат!',
            'JS_FILE_EXT': 'Недопустимое расширение файла!',
            'JS_PASSWORD_COPY': 'Пароли не совпадают!',
            'JS_PASSWORD_LENGTH': 'Минимум 6 символов!',
            'JS_ERROR': 'Неверно заполнено поле!',
            'JS_FILE_SIZE': 'Максимальный размер 5мб!',
            'JS_FILE_BUTTON_NAME': 'Прикрепить файл',
            'JS_FILE_DEFAULT': 'Выберите файл',
            'JS_FILE_ADD': 'Еще один файл',
            'JS_DATE': 'Некорректная дата!',
            'JS_DATETIME': 'Некорректная дата/время!',
            'JS_REQUIRED_LICENSES': 'Согласитесь с условиями',
            'S_CALLBACK': 'Заказать звонок',
            'ERROR_INCLUDE_MODULE_DIGITAL_TITLE': 'Ошибка подключения модуля &laquo;Аспро: Digital-компания&raquo;',
            'ERROR_INCLUDE_MODULE_DIGITAL_TEXT': 'Ошибка подключения модуля &laquo;Аспро: Digital-компания&raquo;.<br />Пожалуйста установите модуль и повторите попытку',
            'S_SERVICES': 'Наши услуги',
            'S_SERVICES_SHORT': 'Услуги',
            'S_TO_ALL_SERVICES': 'Все услуги',
            'S_CATALOG': 'Каталог товаров',
            'S_CATALOG_SHORT': 'Каталог',
            'S_TO_ALL_CATALOG': 'Весь каталог',
            'S_CATALOG_FAVORITES': 'Наши товары',
            'S_CATALOG_FAVORITES_SHORT': 'Товары',
            'S_NEWS': 'Новости',
            'S_TO_ALL_NEWS': 'Все новости',
            'S_COMPANY': 'О компании',
            'S_OTHER': 'Прочее',
            'S_CONTENT': 'Контент',
            'T_JS_ARTICLE': 'Артикул: ',
            'T_JS_NAME': 'Наименование: ',
            'T_JS_PRICE': 'Цена: ',
            'T_JS_QUANTITY': 'Количество: ',
            'T_JS_SUMM': 'Сумма: ',
            'FANCY_CLOSE': 'Закрыть',
            'FANCY_NEXT': 'Вперед',
            'FANCY_PREV': 'Назад',
            'CUSTOM_COLOR_CHOOSE': 'Выбрать',
            'CUSTOM_COLOR_CANCEL': 'Отмена',
            'S_MOBILE_MENU': 'Меню',
            'DIGITAL_T_MENU_BACK': 'Назад',
            'DIGITAL_T_MENU_CALLBACK': 'Обратная связь',
            'DIGITAL_T_MENU_CONTACTS_TITLE': 'Будьте на связи',
            'TITLE_BASKET': 'В корзине товаров на #SUMM#',
            'BASKET_SUMM': '#SUMM#',
            'EMPTY_BASKET': 'пуста',
            'TITLE_BASKET_EMPTY': 'Корзина пуста',
            'BASKET': 'Корзина',
            'SEARCH_TITLE': 'Поиск',
            'SOCIAL_TITLE': 'Оставайтесь на связи',
            'LOGIN': 'Войти',
            'MY_CABINET': 'Личный кабинет',
            'HEADER_SCHEDULE': 'Время работы',
            'SEO_TEXT': 'SEO описание',
            'COMPANY_IMG': 'Картинка компании',
            'COMPANY_TEXT': 'Описание компании',
            'JS_RECAPTCHA_ERROR': 'Не подтверждено!',
            'JS_PROCESSING_ERROR': 'Согласитесь с условиями!'
        })
    </script>
    <script type="text/javascript" src="/bitrix/cache/js/s1/aspro-digital/template_7d685428f05001bcda18d624284d6f9f/template_7d685428f05001bcda18d624284d6f9f_v1.js?1553013916297958"></script>
    <script type="text/javascript">
        var _ba = _ba || [];
        _ba.push(["aid", "05a6ef64448a7bdb76a40ffdd22c66a5"]);
        _ba.push(["host", "centrlp.ru"]);
        (function() {
            var ba = document.createElement("script");
            ba.type = "text/javascript";
            ba.async = true;
            ba.src = (document.location.protocol == "https:" ? "https://" : "http://") + "bitrix.info/ba.js";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(ba, s);
        })();
    </script>

    <script type='text/javascript'>
        var arBasketItems = {};
        var arDigitalOptions = ({
            'SITE_DIR': '/',
            'SITE_ID': 's1',
            'SITE_TEMPLATE_PATH': '/bitrix/templates/aspro-digital',
            'THEME': ({
                'THEME_SWITCHER': 'N',
                'BASE_COLOR': '4',
                'BASE_COLOR_CUSTOM': 'de002b',
                'TOP_MENU': '',
                'TOP_MENU_FIXED': 'Y',
                'COLORED_LOGO': 'N',
                'SIDE_MENU': 'LEFT',
                'SCROLLTOTOP_TYPE': 'ROUND_COLOR',
                'SCROLLTOTOP_POSITION': 'PADDING',
                'CAPTCHA_FORM_TYPE': 'HIDE',
                'PHONE_MASK': '+7 (999) 999-99-99',
                'VALIDATE_PHONE_MASK': '^[+][0-9] [(][0-9]{3}[)] [0-9]{3}[-][0-9]{2}[-][0-9]{2}$',
                'DATE_MASK': 'd.m.y',
                'DATE_PLACEHOLDER': 'дд.мм.гггг',
                'VALIDATE_DATE_MASK': '^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{4}$',
                'DATETIME_MASK': 'd.m.y h:s',
                'DATETIME_PLACEHOLDER': 'дд.мм.гггг чч:мм',
                'VALIDATE_DATETIME_MASK': '^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{4} [0-9]{1,2}\:[0-9]{1,2}$',
                'VALIDATE_FILE_EXT': 'png|jpg|jpeg|gif|doc|docx|xls|xlsx|txt|pdf|odt|rtf',
                'SOCIAL_VK': '',
                'SOCIAL_FACEBOOK': '',
                'SOCIAL_TWITTER': '',
                'SOCIAL_YOUTUBE': '',
                'SOCIAL_ODNOKLASSNIKI': '',
                'SOCIAL_GOOGLEPLUS': '',
                'BANNER_WIDTH': 'AUTO',
                'TEASERS_INDEX': '',
                'CATALOG_INDEX': '',
                'PORTFOLIO_INDEX': '',
                'INSTAGRAMM_INDEX': 'Y',
                'BIGBANNER_ANIMATIONTYPE': 'SLIDE_HORIZONTAL',
                'BIGBANNER_SLIDESSHOWSPEED': '5000',
                'BIGBANNER_ANIMATIONSPEED': '600',
                'PARTNERSBANNER_SLIDESSHOWSPEED': '5000',
                'PARTNERSBANNER_ANIMATIONSPEED': '600',
                'ORDER_VIEW': 'N',
                'ORDER_BASKET_VIEW': 'FLY',
                'URL_BASKET_SECTION': '/cart/',
                'URL_ORDER_SECTION': '/cart/order/',
                'PAGE_WIDTH': '3',
                'PAGE_CONTACTS': '1',
                'HEADER_TYPE': '1',
                'HEADER_TOP_LINE': '',
                'HEADER_FIXED': '2',
                'HEADER_MOBILE': '1',
                'HEADER_MOBILE_MENU': '1',
                'HEADER_MOBILE_MENU_SHOW_TYPE': '',
                'TYPE_SEARCH': 'fixed',
                'PAGE_TITLE': '3',
                'INDEX_TYPE': 'index1',
                'FOOTER_TYPE': '1',
                'FOOTER_TYPE': '1',
                'PRINT_BUTTON': 'N',
                'SHOW_SMARTFILTER': 'N',
                'LICENCE_CHECKED': 'N',
                'FILTER_VIEW': 'VERTICAL',
                'YA_GOLAS': 'Y',
                'YA_COUNTER_ID': '31753816',
                'USE_FORMS_GOALS': 'COMMON',
                'USE_SALE_GOALS': 'Y',
                'USE_DEBUG_GOALS': 'N',
                'IS_BASKET_PAGE': '',
                'IS_ORDER_PAGE': '',
            })
        });
    </script>
    <script type="text/javascript">
        var jsControl = new JCTitleSearch2({
            //'WAIT_IMAGE': '/bitrix/themes/.default/images/wait.gif',
            'AJAX_PAGE': '/company/',
            'CONTAINER_ID': 'title-search',
            'INPUT_ID': 'title-search-input',
            'MIN_QUERY_LEN': 2
        });
    </script>
    <script>
        var lazyLoadInstance = new LazyLoad({
            elements_selector: ".lazy"
                // ... more custom settings?
        });
    </script>
</body>

</html>
<!--9f6db4e856968200c3ca9dc7123dcdcf-->